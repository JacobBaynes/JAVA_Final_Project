public class Course {

    // Attributes
    String subject;
    String number;
    String name;

    // Designated Constructor
    public Course(String subject, String number, String name) {
        this.subject = subject;
        this.number = number;
        this.name = name;
    }

    // Two parameter constructor
    public Course(String subject, String number) {
        this(subject, number, " ");
    }

    public Course(String subject) {
        this(subject, " ", " ");
    }

    // Default Constructor
    public Course() {
        this(" ", " ", " ");
    }


    // Getter and Setter methods
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // toString Override method
    @Override
    public String toString() {
        return "Course{" +
                "subject='" + subject + '\'' +
                ", number='" + number + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
