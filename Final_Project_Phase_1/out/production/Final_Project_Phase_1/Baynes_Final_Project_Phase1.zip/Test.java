/**
 *  Program:    Final Project Phase 1
 *  Author:     Jacob Baynes
 *  Date:       April 16, 2018
 *  Purpose:    This test program instantiates a Student and allows them to enroll in 5 courses.
 */

public class Test {
    public static void main (String[] args) {

        // Set address
        Address a1 = new Address("NY", "08330");
        a1.setCity("New York");
        a1.setStreet("123 Sesame Street");

        // Create new courses
        Course c = new Course("CSC", "251", "Advanced Java");
        Course c1 = new Course("CSC", "134", "C++");
        Course c2 = new Course("CSC", "151", "Java");
        Course c3 = new Course("MAT", "285", "Diff Eq");
        Course c4 = new Course("MAT", "272", "Calculus II");

        // Set student id, name, age, and address
        Student s1 = new Student("750010845", "sally", "jones", 20, a1);

        // Enroll student in five courses
        s1.enroll(c);
        s1.enroll(c1);
        s1.enroll(c2);
        s1.enroll(c3);
        s1.enroll(c4);

        // Print out student information and courses
        System.out.println(s1.toString());


    }
}
