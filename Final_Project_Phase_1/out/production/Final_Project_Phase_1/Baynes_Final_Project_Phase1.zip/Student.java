import java.util.Arrays;

public class Student extends Person {

    // Attributes
    String id;
    Course [] courses = new Course[5];

    private int numberEnrolled = 0;

    // Designated Constructor
    public Student (String id, String firstName, String lastName, int age, Address address) {
        super(firstName, lastName, age, address);
        this.id = id;
        for (int i = 0; i < courses.length; i++) {
            courses[i] = new Course();
        }
    }


    // Getter and Setter methods
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    // Enroll method
    public boolean enroll(Course course) {
        if (numberEnrolled >= 0 && numberEnrolled < courses.length) {
            // not duplicate
            for (Course c:courses) {
                if (c.getSubject().equals(course.getSubject())&& c.getNumber().equals(course.getNumber())) {
                    return false;
                }
            }


            courses[numberEnrolled] = course;
            numberEnrolled++;
            return true;
        } else {
            return false;
        }

    }

    // Add course method
    public boolean addCourse(Course c) {
        if (numberEnrolled < courses.length) {
            courses[numberEnrolled] = c;
            numberEnrolled++;
            return true;
        } else {
            return false;
        }
    }

    // toString Override method
    @Override
    public String toString() {
        String courseList = "";
        for (Course c: courses) {
            courseList += "\n" + c.toString();
        }
        return "Student{" +
                super.toString() +
                "id='" + id + '\'' +
                ", courses=" + Arrays.toString(courses) +
                '}';
    }
}
